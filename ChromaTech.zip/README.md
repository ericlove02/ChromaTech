# ChromaTech

### Instructions 
To install the extension, download the zip file, extract it, then visit the chrome://extensions page. Turn on developer mode in the top right and select unpack extension. Select the folder you just extracted to. ChromaTech will now appear in your browser!

To begin, select the puzzle icon in the top right of your browser, and select ChromaTech from the icon. The ChromTech dashboard will appear, you are now using ChromaTech, welcome!